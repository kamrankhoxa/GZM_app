import React from 'react'
import { View, Text } from 'react-native'

export const showComponent = () => {
    // this would be the function that I user to call my component down
}

const myComponent = (props) => {
    return(
        <View>
            <Text>Oi</Text>
        </View>
    )
}