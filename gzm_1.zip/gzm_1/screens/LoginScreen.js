import * as React from 'react';
import { View, StyleSheet, SafeAreaView } from 'react-native';
import { TextInput, Button } from 'react-native-paper';

//Componentsts
import Logo from '../components/HeaderScreen';

//import useAsyncStorage from '../components/GlobalStorage';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = React.useState('admin');
  const [pass, setPass] = React.useState('admin');

  //  const [user, setUser] = useAsyncStorage('User');

  const _onLoginPress = async() => {
    if (email != '' && pass != '') {
      //To check the input not empty
      //AsyncStorage.setItem('any_key_here', textInputValue);
      //Setting a data to a AsyncStorage with respect to a key
      //setTextInputValue('');
      //Resetting the TextInput
      //alert('Done');
      const data = {
        user: {
          email: 'admin@admin.com',
          
        },
      };

      await AsyncStorage.setItem('user',JSON.stringify(data));

     navigation.replace('Dashboard', {});
      //alert to confirm
    } else {
      alert('Please fill data');
      //alert for the empty InputText
    }
  };
  return (
    <View style={styles.main}>
      <View style={styles.container}>
        <Logo style={styles.logo} />
      </View>

      <TextInput
        label="Email"
        placeholder="email@email.com"
        mode="outlined"
        onChangeText={(email) => setEmail(email)}
      />

      <TextInput
        label="Password"
        placeholder="*******"
        mode="outlined"
        secureTextEntry
        right={<TextInput.Icon icon="eye" />}
        onChangeText={(pass) => setPass(pass)}
      />
      <View style={styles.container_main}>
        <Button icon="account" mode="contained" onPress={_onLoginPress}>
          Login
        </Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  main: {
    padding: 8,
    justifyContent: 'center',
  },
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  container_main: {
    margin: 8,
  },

  logo: {
    aspectRatio: 1,
    resizeMode: 'center',
    marginTop: 10,
    width: 100,
    height: 70,
    flex: 1,
  },
});
