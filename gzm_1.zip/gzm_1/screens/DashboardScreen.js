import React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';
import { Button, TextInput } from 'react-native-paper';

import AsyncStorage from '@react-native-async-storage/async-storage';

export default function DashboardScreen({ navigation }) {
  //const [user, setUser] = useAsyncStorage('User');

  const _onLogout = () => {
    navigation.replace('Login', {});
  };

  getUser = async () => {
    //   //console.log('User');
    //   //console.log(user);
    //   var data = await AsyncStorage.getItem('user');
    //   data = JSON.parse(data);
    //   console.log(data.user.name);
     var data = await AsyncStorage.getItem('user');
     console.log(data);
  };

  return (
    <>
      <View style={styles.container}>
        <Text style={styles.paragraph}>
          <TextInput
            label="Email"
            placeholder="email@email.com"
            mode="outlined"
            value={''}
            onChangeText={''}
          />
          <Button icon="account" mode="contained" onPress={_onLogout}>
            Logout
          </Button>
          <Button icon="account" mode="contained" onPress={getUser}>
            Get User
          </Button>
        </Text>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 128,
    width: 128,
  },
});
