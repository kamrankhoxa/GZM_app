//<ROOT>/shared/APIKit.js
import axios from 'axios';
import useAsyncStorage from "../services/useAsyncStorage";
// const [jwtAuth, updatejwtAuth, clearjwtAuth] = useAsyncStorage("jwt");
// Create axios client, pre-configured with baseURL
let APIKit = axios.create({
  baseURL: 'http://192.168.1.5:1337',
  timeout: 10000,
});

// Set JSON Web Token in Client to be included in all calls
export const setClientToken = token => {
  APIKit.interceptors.request.use(function(config) {
    config.headers.Authorization = `Bearer ${token}`;
    return config;
  });
};

export const cleartoken = token => {
  APIKit.interceptors.request.use(function(config) {
    config.headers.Authorization = ``;
    return config;
  });
};


export default APIKit;