import { View, StyleSheet, Image, ScrollView } from "react-native";
import React, { useEffect, useState } from "react";

import { Button, TextInput, Searchbar } from "react-native-paper";
import { BottomNavigation, Text } from "react-native-paper";
import axios from "axios";
import useAsyncStorage from "../../services/useAsyncStorage";
import { useTheme } from "react-native-paper";
import { CategoriesButtons } from "./CategoriesButtons";

import LoginScreen from '../Login';
import RegisterScreen from '../Register';
import { NewsFeed } from "./NewsFeed";

const HomeRoute = () => {
  const theme = useTheme();
  const ref = React.useRef(null);
  const [categoriesData, setCategoriesData] = React.useState(null);

  async function _getResponse() {
    axios
      .get("http://192.168.1.5:1337/api/categories")
      .then((response) => {
        console.log(JSON.stringify(response.data.data));
        setCategoriesData(response.data.data);
      })
      .catch((err) => console.log("error " + err));
  }
  useEffect(() => {
    // console.log(JSON.parse(jwtAuth));
    Promise.all(_getResponse())
      .then((response) => {
        // console.log(response);
      })
      .catch((err) => console.log("error " + err));
  }, []);

  return (
    <>
      <View style={{ marginTop: 25 }}>
        <Searchbar
          placeholder="Search"
          placeholderTextColor={theme.colors.secondary}
          //onChangeText={onChangeSearch}
          //value={searchQuery}
          mode="bar"
          iconColor="grey"
          onIconPress={() => ref.current.focus()}
          ref={ref}
        />
      </View>
      <View style={{ marginTop: 12 }}>
        <CategoriesButtons data={categoriesData} />
      </View>
      <View style={{ marginTop: 12 }}>
        <NewsFeed data={categoriesData} />
      </View>
    </>
  );
};

const CommunityRoute = () => (
  <View style={{ marginTop: 25 }}>
    <Text>CommunityRoute</Text>
  </View>
);

const LiveRoute = () => (
  <View style={{ marginTop: 25 }}>
    <Text>LiveRoute</Text>
  </View>
);

const AccountsRoute = ({ navigation }) => (
<View style={{ marginTop: 25 }}>
  <Text>Accounts</Text>
</View>);

const MyComponent = ({ navigation }) => {
  useEffect(()=>{
  },[])
  const [index, setIndex] = React.useState(0);
  const [routes] = React.useState([
    {
      key: "Home",
      title: "Home",
      focusedIcon: "home",
      unfocusedIcon: "home-outline",
    },
    { key: "Community", title: "Community", focusedIcon: "newspaper" },
    { key: "Live", title: "Live", focusedIcon: "album" },
    {
      key: "Accounts",
      title: "Account",
      focusedIcon: "account",
      unfocusedIcon: "account-outline",
    },
  ]);

  const renderScene = BottomNavigation.SceneMap({
    Home: HomeRoute,
    Community: CommunityRoute,
    Live: LiveRoute,
    Accounts: AccountsRoute,
  });

  return (
    <BottomNavigation
      navigationState={{ index, routes }}
      onIndexChange={setIndex}
      renderScene={renderScene}
    />
  );
};

export default MyComponent;
