import React from "react";
import { View, StyleSheet, Image, ScrollView } from "react-native";
import { useEffect, useState } from "react";

import { Button, TextInput, Searchbar } from "react-native-paper";
import { BottomNavigation, Text } from "react-native-paper";
import axios from "axios";
import useAsyncStorage from "../services/useAsyncStorage";
import { useTheme } from "react-native-paper";
import { CategoriesButtons } from "./components/CategoriesButtons";
import { NewsFeed } from "./components/NewsFeed";

import { MaterialCommunityIcons } from '@expo/vector-icons';

export default function DashboardScreen({ navigation }) {
  const [jwtAuth, updatejwtAuth, clearjwtAuth] = useAsyncStorage("@jwt:token");
  const [userData, updateuserData, clearuserData] = useAsyncStorage("userdata");
  const [categoriesData, setCategoriesData] = React.useState(null);

  async function _getResponse() {
    let token = await JSON.parse(jwtAuth);
    axios
      .get("http://192.168.1.5:1337/api/categories", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        // console.log(JSON.stringify(response.data.data));
        setCategoriesData(response.data.data);
      }).catch(err => console.log("error " + err));
  }
  useEffect(() => {
    // console.log(JSON.parse(jwtAuth));
      Promise.allSettled(_getResponse())
      .then((response)=>{
        console.log(response);
      })
      .catch(err => console.log("error " + err))
    }, [userData]);

  const HomeRoute = () => {
    const theme = useTheme();
    const ref = React.useRef(null);

    return (
      <>
        <View style={{ marginTop: 25 }}>
          <Searchbar
            placeholder="Search"
            placeholderTextColor={theme.colors.secondary}
            //onChangeText={onChangeSearch}
            //value={searchQuery}
            mode="bar"
            iconColor="grey"
            onIconPress={() => ref.current.focus()}
            ref={ref}
          />
        </View>
        <View style={{ marginTop: 12 }}>
          <CategoriesButtons data={categoriesData} />
        </View>
        <View style={{ marginTop: 12 }}>
          <NewsFeed data={categoriesData} />
        </View>
      </>
    );
  };

  const CommunityRoute = () => {
    const theme = useTheme();
    return (
      <>
        <View style={styles.main}>
          <View style={styles.container}>
            <Text>Community</Text>
          </View>
        </View>
      </>
    );
  };

  const SettingsRoute = () => {
    const theme = useTheme();
    return (
      <>
        <View style={styles.main}>
          <View style={styles.container}>
            <Text>Dashboard Settings</Text>
          </View>
          <Button
            buttonColor={theme.colors.primary}
            icon="account"
            textColor={theme.colors.onPrimary}
            mode="contained"
            onPress={_onLogout}
          >
            Logout
          </Button>
        </View>
      </>
    );
  };

  const _onLogout = () => {
    clearjwtAuth();
    navigation.replace("Main", {});
  };

  const _getUser = async () => {
    console.log(userData);
    console.log(jwtAuth);
  };

  // const AlbumsRoute = () => <Text>Albums</Text>;

  // const RecentsRoute = () => <Text>Recents</Text>;

  // const NotificationsRoute = () => <Text>Notifications</Text>;

  const MyComponent = () => {
    const [index, setIndex] = React.useState(0);
    const [routes] = React.useState([
      {
        key: "home",
        title: "Home",
        focusedIcon: "home",
        unfocusedIcon: "home-outline",
      },
      {
        key: "community",
        title: "Community",
        focusedIcon: "newspaper",
        // unfocusedIcon: "newspaper-outline",
      },
      {
        key: "settings",
        title: "Settings",
        focusedIcon: "cog",
        unfocusedIcon: "cog-outline",
      },

      // { key: 'recents', title: 'Recents', focusedIcon: 'history' },
      // { key: 'notifications', title: 'Notifications', focusedIcon: 'bell', unfocusedIcon: 'bell-outline' },
    ]);

    const renderScene = BottomNavigation.SceneMap({
      home: HomeRoute,
      community: CommunityRoute,
      settings: SettingsRoute,
      // recents: RecentsRoute,
      // notifications: NotificationsRoute,
    });
    return (
      <BottomNavigation
        navigationState={{ index, routes }}
        onIndexChange={setIndex}
        renderScene={renderScene}
      />
    );
  };

  return (
    <>
      {/* <View style={styles.container}>
        <View style={styles.paragraph}>
          <Button icon="account" mode="contained" onPress={_onLogout}>
            Logout
          </Button>
          <Button icon="account" mode="contained" onPress={_getUser}>
            Get User
          </Button>
          
        </View>
        </View>
       */}
      <MyComponent />
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: "bold",
    textAlign: "center",
  },
  logo: {
    height: 128,
    width: 128,
  },
});
